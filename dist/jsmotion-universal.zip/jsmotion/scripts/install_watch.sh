#!/usr/bin/env bash
# Instala a skill /watch (claude-watch) e dependências no ambiente atual. Idempotente.
# --voz: também instala o faster-whisper (alinhamento da narração no vídeo narrado).
# --apresentador: --voz + OpenCV (rastreio do rosto para editar vídeo de pessoa falando / avatar).
set -e
source "$(dirname "$0")/paths.sh"
DIR="${WATCH_DIR:-$WORK/watch}"
if [ ! -f "$DIR/scripts/watch.py" ]; then
  git clone -q https://github.com/taoufik123-collab/claude-watch.git "$DIR"
fi
command -v yt-dlp >/dev/null 2>&1 || pip install -q yt-dlp --break-system-packages
command -v ffmpeg >/dev/null 2>&1 || (apt-get install -y -qq ffmpeg >/dev/null 2>&1 || true)
pip show brotli >/dev/null 2>&1 || pip install -q brotli --break-system-packages
python3 -c "import playwright" 2>/dev/null || pip install -q playwright --break-system-packages
python3 -c "import fontTools" 2>/dev/null || pip install -q fonttools --break-system-packages   # fonte 3D (font3d.py)
# vídeo narrado: alinhamento palavra por palavra da voz (voice.py --audio). Só com --voz (é pesado).
if [ "$1" = "--voz" ] || [ "$1" = "--apresentador" ]; then python3 -c "import faster_whisper" 2>/dev/null || pip install -q faster-whisper --break-system-packages; fi
if [ "$1" = "--apresentador" ]; then python3 -c "import cv2" 2>/dev/null || pip install -q opencv-python-headless --break-system-packages; fi
echo "watch pronto em $DIR · trabalho: $WORK · entregas: $OUT"
